package lv.rvt;

public class Main {
    public static void main(String[] args) throws Exception {
        UI.MainMenu();
    }
}
