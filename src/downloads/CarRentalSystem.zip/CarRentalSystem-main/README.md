# Par sistēmu
Sistēma paredzēta mašīnu īzirēšanas organizācijai. Sistēma piedava pievienot, dzēst un rediģēt mašīnas, klientus un īre. Sistēma ļauj redzēt statistiku (kopēja peļņa, vidēja peļņa no mašīnas, vidēja īres cena, visbiežāk izirēta mašīna).
# Lietotāja interfeisa apraksts
Programma izvada atrašanas vietu un izvēle uz kurieni pārvesties ar ciparu ievadīšanu (piem.

Sakums > Statistika >
1. Kopēja peļņa
2. Vidēja peļņa no māšīnas
3. vidēja īres cena
4. visbiežāk izirēta mašīna
5. Atpakaļ

   Ievadiet poziciju: )
# Funkciju apraksti
Mašīnas pievienošana/dzēšana - sistēmas administrators var pievienot vai izdzēst pieejamas mašīnas.

Mašīnas rediģēšana - sistēmas administrators var rediģēt mašīnas pieejamību izirēšanai un citu informāciju.

Mašīnas filtrēšana - sistēmas lietotājs var atlasīt tabulu ar mašīnam pec kriterijam (piem. nobraukums >1000km)

Mašīnas kārtošana - sistēmas lietotājs var atlasīt tabulu ar mašīnam ar sakārtotam pozicijam (piem. mašīnas ar mazāku nobraukumu pirmie).

Statistikas rīki - sistēmas lietotājs var atlasīt statistīku (piem. kopēja peļņa, vidēja peļņa no mašīnas utt.)
